from django.contrib import admin 

# Register your models here.
from .models import Question,ModuleMaster

#admin.site.register(Question)

class QuestionAdmin(admin.ModelAdmin):
    list_display = ("question_title", "question_code","sequence", "question_type","status")
    search_fields = ['question_title', 'question_code', 'question_type']
    #readonly_fields = ["question_type"]
    list_per_page = 5

class ModuleMasterAdmin(admin.ModelAdmin):
    list_display = ("module_name", "module_code", "short_description","sequence","status")
    search_fields = ['module_name', 'module_code', 'short_description']
    list_per_page = 5

admin.site.register(Question, QuestionAdmin)
admin.site.register(ModuleMaster, ModuleMasterAdmin)