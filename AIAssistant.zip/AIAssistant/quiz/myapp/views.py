from django.shortcuts import render
import requests
import json
from django.http import HttpResponse
#import openai
import os
import pyttsx3
import pyaudio
import speech_recognition as sr
from pyexpat.errors import messages
from openai import OpenAI
#from rapidfuzz import fuzz
from fuzzywuzzy import fuzz
from sentence_transformers import SentenceTransformer, util
from transformers import AutoTokenizer,AutoModel
from .models import  Question,ModuleMaster
from django.db.models import Count, Exists, Q
from django.shortcuts import redirect

from django.http import JsonResponse
from transformers import pipeline
import functools  #Used for caching
from strsimpy.jaro_winkler import JaroWinkler # strsimpy for answer verification
import textdistance  #Alternate way for answer verification
from polyfuzz import PolyFuzz  #Alternate way for answer verification

def run_task(request):
   speechtx("Button clicked")
   text = """<h1>welcome to my app !</h1>"""
   return HttpResponse(text)
#openai.api_key=os.getenv('OPENAI_API_KEY')
def say(text):
    os.system(f"say {text}")

def speechtx(x):
    engine=pyttsx3.init()
    voices=engine.getProperty('voices')
    engine.setProperty('voice',voices[0].id)
    rate=engine.getProperty('rate')
    engine.setProperty('rate',150)
    engine.say(x)
    engine.runAndWait()

# obtain audio from the microphone
def takeCommand_bkp(message):
   print(f"message: {message}")
   if(message!=''):
    print(message)
    speechtx(message)
    r=sr.Recognizer()
    print('you are here-takeCommand')
    with sr.Microphone() as source:
        r.pause_threshold=1
        r.adjust_for_ambient_noise(source)
        audio = r.listen(source)
        try:
            print("recognizing...")
            speechtx("Please wait...")
            query= r.recognize_google(audio,language="en-in")
            print(f"User said: {query}")
            #speechtx(query)
        except Exception as e:
            query="Not Understanding"
            print(f"User said: {query}")
           # raise e
        return query


def takeCommand(message):
   print(f"message: {message}")
   if(message!=''):
    print(message)
    speechtx(message)
    r=sr.Recognizer()
    print('you are here-takeCommand')
    try:
      with sr.Microphone() as source:
        try:
            print("inside try -catch block of takeCommand")
            r.pause_threshold=1
            print("p1")
            r.adjust_for_ambient_noise(source)
            print("p2")
            audio = r.listen(source)
            print("p3")
            print("recognizing...")
            speechtx("Please wait...")
            query= r.recognize_google(audio,language="en-in")
            print("p4")
            print(f"User said: {query}")
            #speechtx(query)
        except Exception as e:
            query="Not Understanding"
            print(f"Exception Details: {e}")
            print(f"User said: {query}")
           # raise e
        return query
    except Exception as e2:
      print(f"Exception Details2: {e2}")
      return "error"


#Currently it is not in used
def getResponseFromOpenAI(methodType):

    client = OpenAI(api_key="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")
    #client.api_key = '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'

    messages = [
        {"role": "system", "content": "You are a helpful assistant."}
    ]
    while True:
       # message=input("User : ")
       if methodType==1:
           message = input("User : ")
       else:
           message=takeCommand('')
       print(message)
       if message:
            messages.append({"role":"user","content":message},)
            chat = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=messages,
            max_tokens= 10
            )
            reply=chat.choices[0].message.content
            print(f"ChatGPT: {reply}")
            messages.append({"role":"assistant","content":reply})

#Currently it is not in used
def getResultScore_rapidfuzz(userAnswer,correctAnswer):
   accuracy=fuzz.ratio(userAnswer,correctAnswer)
   print(f"accuracy :{accuracy}")
   return accuracy

#Currently it is not in used
def getResultScore_fuzzywuzzy(userAnswer,correctAnswer):
   accuracy=fuzz.ratio(userAnswer,correctAnswer)
   print(f"accuracy :{accuracy}")
   return accuracy

   


#Currently it is not in used
def getCorrectAnswer(methodType):

   client = OpenAI(api_key="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")
    #client.api_key = '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'
   print('getCorrectAnswer running')
   messages = [
        {"role": "system", "content": "You are a helpful assistant."}
   ]
   # message=input("User : ")
   if methodType==1:
      message = input("User : ")
   else:
      message=takeCommand('')
   print(message)
   if message:
      messages.append({"role":"user","content":message},)
      chat = client.chat.completions.create(
      model="gpt-4o-mini",
      messages=messages,
      max_tokens= 10
      )
      reply=chat.choices[0].message.content
      print(f"ChatGPT: {reply}")
      messages.append({"role":"assistant","content":reply})

def is_correct_textdistance(user_answer, correct_answer, threshold=0.9):
   similarity = textdistance.cosine.normalized_similarity(user_answer.lower(), correct_answer.lower())
   print(f'Method:is_correct_textdistance User Answer:{user_answer} and Score:{similarity}')
   return similarity >= threshold

def is_correct_strsimpy(user_answer,correct_answer,threshold=0.9):
   jarowinkler=JaroWinkler()
   score =jarowinkler.similarity(user_answer.lower(),correct_answer.lower())
   print(f'Method:is_correct_strsimpy User Answer:{user_answer} and Score:{score}')
   return score

def is_correct_polyfuzz(user_answer,correct_answer,threshold=0.9):
   model = PolyFuzz("TF-IDF")
   model.match([user_answer], [correct_answer])
   score=model.get_matches()
   print(f'Method:is_correct_polyfuzz User Answer:{user_answer} and Score:{score}')
   return score

# Create your views here.
def index(request):
  # allQuestionsvoice = Question.objects.filter(question_type='voice', question_code='1').all()[:1]
  # allQuestionsmcq = Question.objects.filter(question_type='mcq', question_code='2').all()[:1]
   modules=ModuleMaster.objects.filter(status='True').order_by('sequence').all()
   #ques_answer="static answer"

   #Some other queries
   #ModuleMaster.objects.filter(module_name__startswith='Quiz').values()
   #ModuleMaster.objects.values('id', 'module_name')
   
   
   
   # user_answer='Narendra Modi'
   # correct_answer='The Prime minister of India is Narendra Modi'
   # is_correct_strsimpy(user_answer,correct_answer,0.9)
   # is_correct_textdistance(user_answer,correct_answer,0.9)
   # is_correct_polyfuzz(user_answer,correct_answer,"")  
   # getResultScore_sentence_transformers(user_answer,correct_answer,"")  

   
   
   #params = {'modules':modules,'allQuestionsvoice': allQuestionsvoice,'allQuestionsmcq':allQuestionsmcq,'ques_answer':ques_answer}
   params = {'modules':modules}

   return render(request, 'myapp/index.html',params)

def thankyou(request):
   correct_answer_count=3
   total_question_count=5
   worng_answer_count=2
   result='Pass'
   #message=f'You scored {correct_answer_count} out of {total_question_count}!'
   message=''
   params = {'result':result,'message':message,'correct_answer_count':correct_answer_count,'total_question_count':total_question_count,'worng_answer_count':worng_answer_count}

   return render(request, 'myapp/thankyou.html',params)

def chatbot_poc(request):
   # other view code here
   questions = Question.objects.filter(question_type='chatgpt', status='True').order_by('sequence').all()[:1]
   print('hellooooo')
   print(questions)
   qa=pipeline('question-answering')
   question_ctx=""
   for q in questions:
     question_ctx=q.description
     question=q.question_title
   res=qa(context=question_ctx,question=question)
   ques_answer=res['answer']
   print(res)
   print(ques_answer)
   params = {'question': question,'ques_answer':ques_answer}
   return render(request, 'myapp/chatbot_poc.html', params)


def chatbot_poc2(request):
   # other view code here
   #allQuestionsvoice = Question.objects.filter(question_type='voice', question_code='1').all()[:1]
   questions = Question.objects.filter(question_type='chatgpt', status='True').order_by('sequence').all()[:1]
   
   qa=pipeline('question-answering')
   question_ctx=""
   for q in questions:
     question_ctx=q.description
     question=q.question_title
     aiprompt=q.ai_prompt
   
   answer=getCorrectAnswerOpenAI(question,aiprompt)
   params = {'question': question,'answer':answer}
   return render(request, 'myapp/chatbot_poc2.html', params)

def chatbot_poc3(request):
   # other view code here
   #allQuestionsvoice = Question.objects.filter(question_type='voice', question_code='1').all()[:1]
   questions = Question.objects.filter(question_type='chatgpt', status='True').order_by('sequence').all()[:1]
   
   qa=pipeline('question-answering')
   question_ctx=""
   for q in questions:
     question_ctx=q.description
     question=q.question_title
     aiprompt=q.ai_prompt
   
   correctanswer=getCorrectAnswerOpenAI(question,aiprompt)
   res=qa(context=correctanswer,question=question)
   ques_answer=res['answer']
   print(res)
   print(ques_answer)
   print('sadiq')
   params = {'question': question,'ques_answer':ques_answer}
   return render(request, 'myapp/chatbot_poc3.html', params)

def survey(request):
   # other view code here
   allQuestionsvoice = Question.objects.filter(question_type='voice' , status='True').order_by('sequence','question_title').all()[:5]
   #allQuestionsmcq = Question.objects.filter(question_type='mcq', question_code='2').all()[:1]
   #print(allQuestionsvoice)
   #totalQuestions=Question.objects.filter(question_type='voice').all().count()
   totalQuestions=allQuestionsvoice.count()
   #print(f'totalQuestions:{totalQuestions} ')
   
   #print(totalQuestions)
   progressPercentage=int(100/totalQuestions)
   #progressPercentage=50
   #print(progressPercentage)
   #question_ctx="Sachin Ramesh Tendulkar (born 24 April 1973) is an Indian former international cricketer who captained the Indian national team. He is widely regarded as one of the greatest cricketers of all time, and is the holder of several world records, including being the all-time highest run-scorer in both ODI and Test cricket, receiving the most player of the match awards in international cricket, and being the only batsman to score 100 international centuries. Tendulkar was a Member of Parliament, Rajya Sabha by presidential nomination from 2012 to 2018. Tendulkar was born at the Nirmal Nursing Home in the Dadar neighbourhood of Bombay, Maharashtra on 24 April 1973 into a Maharastrian family. His father, Ramesh Tendulkar, was a Marathi-language novelist and poet while his mother, Rajni, worked in the insurance industry"
   #question="Where he has born?"
  

  # answer=getUserAnswer()
   #answer='Sachin Tendulkar'
   # accuracy=getResultScore_fuzzywuzzy(answer,"Prime Minister of India is Narendra Modi")
   # accuracy=getResultScore_fuzzywuzzy(answer,"Prime Minister of India is Narendra Modi")
  
   #accuracy=getResultScore_sentence_transformers(answer,"Prime Minister of India is Narendra Modi","")
   
  # accuracy=getResultScore("Narendra Modi","Prime Minister of India is Narendra Modi")
   
   # api_url = "https://jsonplaceholder.typicode.com/todos"
   # todo = {"userId": 1, "title": "Buy milk", "completed": False}
   # headers =  {"Content-Type":"application/json"}
   # response = requests.post(api_url, data=json.dumps(todo), headers=headers)
   # response.json()
   # response.status_code
   # print(response.json())
   #accuracy=1
   #totalQuestions=2
   params = {'allQuestionsvoice': allQuestionsvoice,'totalQuestions':totalQuestions,'progressPercentage':progressPercentage}
   #print(params)
   #params={'question':'Who is the Prime minister of India?','answer':answer,'accuracy':accuracy}
   #return render(request, 'myapp/index.html', response.json())
   return render(request, 'myapp/survey.html', params)


def activateListener(request):
   #allQuestionsvoice = Question.objects.filter(Q(question_type='voice')).all()[:1]
   print('calling activate listener')
   if request.method=='GET':
      print('getting value from GET')
      questionCode=request.GET['questionCode']
      question_id=request.GET['question_id']
      print(f'question_id:{question_id}')
   else:
      questionCode=1
   
   allQuestionsvoice = Question.objects.filter(id=question_id).all()[:1]
   
   question=""
   aiprompt=""
   correctanswer=""
   saved_correct_answer=""
   accuracy=""
   for q in allQuestionsvoice:
      question=q.question_title
      aiprompt=q.ai_prompt
      saved_correct_answer=q.correct_answer
   
  
   #Enable below code for live case
   answer=getUserAnswer(question)
   print (f'User Answer:{answer}')
   if answer=='Not Understanding':
      accuracy='NA'
   elif (saved_correct_answer!=''):
      correctanswer=saved_correct_answer
      print (f'saved_correct_answer:{saved_correct_answer}')
   else:
      correctanswer=getCorrectAnswerOpenAI(question,aiprompt)
      qa=pipeline('question-answering')
      res=qa(context=correctanswer,question=question)
      correctanswer=res['answer']
      #accuracy=getResultScore_sentence_transformers(answer,correctanswer,aiprompt) 
   print (f'correct answer:{correctanswer}')
   
   
   

   #Disable below code for live case
   # answer="rahul" 
   # correctanswer='Prime Minister of India is Narendra Modi' 
   # qa=pipeline('question-answering')
   # res=qa(context=correctanswer,question=question)
   # correctanswer=res['answer']
   
   
   if accuracy!='NA':
      accuracy=getResultScore_sentence_transformers(answer,correctanswer,aiprompt)  
   
   #result = "success"
   return JsonResponse({'question': question,'accuracy': accuracy,'answer':answer})
      


def getUserAnswer(question):
   answer=takeCommand(question)
   print(answer)
   print(f"getUserAnswer(): {answer}")
   
   return answer


@functools.lru_cache(maxsize=None)  #Code for caching
def getCorrectAnswerOpenAI(message,ai_prompt):

   client = OpenAI(api_key="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")
    #client.api_key = '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'

   messages = [
        {"role": "system", "content": ai_prompt}
   ]

   print("data is not coming from caching.")
   print(message)
   if message:
      messages.append({"role":"user","content":message},)
      chat = client.chat.completions.create(
      model="gpt-4o-mini",
      messages=messages,
      max_tokens= 50
      )
      reply=chat.choices[0].message.content
      print(f"ChatGPT: {reply}")
      messages.append({"role":"assistant","content":reply})
      return reply

def getResultScore_sentence_transformers(userAnswer,correctAnswer,aiprompt):
   # model = AutoModel.from_pretrained(
   #  'sentence-transformers/all-MiniLM-L6-v2',
   # )
   #model = SentenceTransformer('all-MiniLM-L6-v2',token=False)
   model = SentenceTransformer('paraphrase-MiniLM-L6-v2',token=False)
   #model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
  # tokenizer = AutoTokenizer.from_pretrained("sentence-transformers/all-MiniLM-L6-v2")
   #model = AutoModel.from_pretrained("sentence-transformers/all-MiniLM-L6-v2")
   #model=SentenceTransformer('AI-ModelScope/all-MiniLM-L6-v2')
   user_answer = userAnswer#"The capital of France is Paris."
   correct_answer = correctAnswer#"Paris is the capital city of France."
   embeddings = model.encode([user_answer, correct_answer])
   similarity = util.cos_sim(embeddings[0], embeddings[1]).item()
   is_correct = similarity > 0.7  # Adjust threshold as needed
   print(f'Method:getResultScore_sentence_transformers User Answer:{userAnswer} and Score:{similarity}')
   print(f"accuracy :{similarity*100}")
   return similarity*100
  # return 1


def readInput(request):
   if request.method=='POST':
      print('getting value')
      input_value=request.POST.get('questionCode')
      return HttpResponse(f"Question Code: {input_value}")
      
   params = {'question': 'question','ques_answer':'ques_answer'}
   print(params)
   return render(request, 'myapp/chatbot_poc.html', params)
   
      
  