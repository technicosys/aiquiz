from django.db import models

STATUS_CHOICES = [
    ("Active", "Active"),
    ("Inactive", "Inactive")
]
QUESTION_TYPE_CHOICES = [
    ("voice", "Voice Based"),
    ("mcq", "Multiple Choice Question"),
    ("chatgpt", "ChatGPT"),
]
STATIC_IMAGE_MODULES_CHOICES = [
    ("myapp/assets/images/item-img/ai_assistance.png","AI_Assistance"),
    ("myapp/assets/images/item-img/ai_assistance2.jpg","AI_Assistance New"),
    ("myapp/assets/images/item-img/chatbot.jpg","Chatbot_1"),
    ("myapp/assets/images/item-img/chatbot2.png","Chatbot_2"),
    ("myapp/assets/images/item-img/chatbot3.png","Chatbot_3"),
]
LARGE_STATIC_IMAGE_MODULES_CHOICES = [
    ("myapp/assets/images/background/bg_0.png","Girl_With_Laptop"),
    ("myapp/assets/images/item-img/chatbot_hd.jpg","Chatbot_1"),
    ("myapp/assets/images/item-img/chatbot2_full.png","Chatbot_2"),
    ("myapp/assets/images/item-img/chatbot3_full.png","Chatbot_3"),
]
ACTION_METHOD_CHOICES = [
    ("survey", "Survey"),
    ("chatbot", "chatbot"),
    ("chatbot2", "chatbot2"),
    ("chatbot3", "chatbot3"),
    ("#", "No Action"),
]
# Create your models here.
class Question(models.Model):
    #question_id=models.AutoField()
    question_title=models.CharField(max_length=200,verbose_name="Question Title",help_text=("type the question"))
    question_code=models.CharField(max_length=200,default="",verbose_name="Question Code", blank=True)
    correct_answer=models.CharField(max_length=200,default="",verbose_name="Correct Answer", blank=True)
    description=models.CharField(max_length=5000,default="",verbose_name="Description", blank=True)
    ai_prompt=models.CharField(max_length=2000,default="",verbose_name="AI Prompt", blank=True)
    #status = models.CharField(max_length=15, choices=STATUS_CHOICES)
    status = models.BooleanField(default=True,verbose_name="Status")
    sequence=models.IntegerField(default=0,verbose_name="Sequence No")
    create_date=models.DateField()
    question_type=models.CharField(max_length=200,verbose_name="Question Type",choices=QUESTION_TYPE_CHOICES)
    answer1=models.CharField(max_length=200,default="", blank=True)
    answer2=models.CharField(max_length=200,default="", blank=True)
    answer3=models.CharField(max_length=200,default="", blank=True)
    answer4=models.CharField(max_length=200,default="", blank=True)

    def __str__(self):
        return self.question_title

class ModuleMaster(models.Model):
   # module_id=models.AutoField()
    module_name=models.CharField(max_length=200,verbose_name="Module Name",help_text=("type the module name"))
    module_code=models.CharField(max_length=200,default="",verbose_name="Module Code", blank=True)
    image_name=models.CharField(max_length=200,default="",verbose_name="Image Name", blank=True,choices=STATIC_IMAGE_MODULES_CHOICES)
    large_image_name=models.CharField(max_length=200,default="",verbose_name="Large Image Name", blank=True,choices=LARGE_STATIC_IMAGE_MODULES_CHOICES)
    short_description=models.CharField(max_length=5000,default="",verbose_name="Short Description", blank=True)   
    action_method=models.CharField(max_length=200,default="",verbose_name="Action Method", blank=True,choices=ACTION_METHOD_CHOICES)
    status = models.BooleanField(default=True,verbose_name="Status")
    sequence=models.IntegerField(default=0,verbose_name="Sequence No")
    create_date=models.DateField()

    def __str__(self):
        return self.module_name