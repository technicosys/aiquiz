"""
URL configuration for quiz project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from myapp import views

#Django admin header customization
admin.site.site_header="AI Based Survey"
admin.site.site_title="Admin Panel"
admin.site.index_title="AI Based Survey"

urlpatterns = [
    path('admin/', admin.site.urls),     
    path('survey', views.survey, name='survey'),
    path('chatbot', views.chatbot_poc, name='chatbot_poc'),
    path('chatbot2', views.chatbot_poc2, name='chatbot_poc2'),
    path('chatbot3', views.chatbot_poc3, name='chatbot_poc3'),
    path('', views.index, name='index'),
    path('run-task/', views.run_task,name='run_task'),   
    path('readInput/', views.readInput,name='readInput'),   
    path('activateListener/', views.activateListener, name='activateListener'), 
    path('thankyou', views.thankyou, name='thankyou'),
]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
